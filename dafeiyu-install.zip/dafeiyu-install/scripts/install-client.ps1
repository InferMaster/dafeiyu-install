﻿# 可选第 10 步：安装 Tauri 桌面客户端（真正的 exe 窗口，不是 Edge 小窗口）。可以重复跑。
# 用法：powershell -NoProfile -ExecutionPolicy Bypass -File install-client.ps1 -Dir <工作目录>
#       powershell -NoProfile -ExecutionPolicy Bypass -File install-client.ps1 -Dir <工作目录> -Uninstall
# 客户端 exe 从同目录的 dafeiyu-dir.txt 读工作目录，因此观众装在哪个盘都能用。
param([Parameter(Mandatory)][string]$Dir, [switch]$Uninstall)
. "$PSScriptRoot\common.ps1"
$ErrorActionPreference = 'Continue'
$Dir = [IO.Path]::GetFullPath($Dir).TrimEnd('\')
$clientDir = Join-Path $Dir '客户端'
$exeName = '小肥工作台.exe'
$exePath = Join-Path $clientDir $exeName
$marker  = Join-Path $clientDir 'dafeiyu-dir.txt'
$srcExe  = Join-Path (Split-Path $PSScriptRoot) 'assets\client\小肥工作台.exe'
$desktop = [Environment]::GetFolderPath('Desktop')
$lnkPath = Join-Path $desktop '小肥工作台（客户端）.lnk'

if ($Uninstall) {
    # 只删客户端和它自己的桌面图标；不碰原来的「小肥工作台」启动脚本图标、不碰工作目录里的任何数据
    Get-Process -Name '小肥工作台' -ErrorAction SilentlyContinue | ForEach-Object {
        try { Stop-Process -Id $_.Id -ErrorAction Stop } catch {}
    }
    foreach ($f in @($lnkPath, $exePath, $marker)) { if (Test-Path $f) { Remove-Item $f -Force -ErrorAction SilentlyContinue } }
    if (Test-Path $clientDir) {
        $left = @(Get-ChildItem $clientDir -Force -ErrorAction SilentlyContinue)
        if ($left.Count -eq 0) { Remove-Item $clientDir -Force -ErrorAction SilentlyContinue }
    }
    Write-Output 'CLIENT_UNINSTALL ok=1 客户端已卸载（原来的工作台图标和数据都还在）'
    exit 0
}

if (-not (Test-Path "$Dir\tools\workbench\server.py")) {
    Write-Output 'CLIENT_INSTALL ok=0 error=这个目录里没找到工作台小服务，先装好工作台再装客户端'
    exit 1
}
if (-not (Test-Path $srcExe)) {
    Write-Output 'CLIENT_INSTALL ok=0 error=Skill 里没找到客户端 exe（assets\client\小肥工作台.exe）'
    exit 1
}
New-Item -ItemType Directory -Force $clientDir | Out-Null
Copy-Item $srcExe $exePath -Force
[IO.File]::WriteAllText($marker, $Dir, (New-Object Text.UTF8Encoding($false)))

# 桌面图标：用「（客户端）」区别于原来的 Edge 小窗口图标，两个可以并存
try {
    $ws = New-Object -ComObject WScript.Shell
    $l = $ws.CreateShortcut($lnkPath)
    $l.TargetPath = $exePath
    $l.WorkingDirectory = $clientDir
    $l.Description = '小肥工作台桌面客户端'
    $l.Save()
    $linkOk = 1
} catch { $linkOk = 0 }

$size = [math]::Round((Get-Item $exePath).Length / 1MB, 1)
Write-Output "CLIENT_INSTALL ok=1 exe=$exePath size=${size}MB link=$linkOk marker=$marker"
Write-Output 'CLIENT_INSTALL 双击桌面的「小肥工作台（客户端）」即可打开独立窗口；原来的「小肥工作台」图标照旧是 Edge 小窗口，两个不冲突。'
